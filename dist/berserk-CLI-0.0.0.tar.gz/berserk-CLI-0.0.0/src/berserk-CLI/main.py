'''
import berserk
import chess

session = berserk.TokenSession(API_TOKEN)
client = berserk.Client(session=session)
'''

def add_two(number):
    return number + 2